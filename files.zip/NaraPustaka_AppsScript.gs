// =============================================================
// NARA PUSTAKA - Google Apps Script Backend
// Salin seluruh kode ini ke Google Apps Script Editor
// URL: https://script.google.com/
// =============================================================
// CARA DEPLOY:
// 1. Buka https://script.google.com/
// 2. Buat project baru, paste kode ini
// 3. Klik "Deploy" > "New Deployment"
// 4. Pilih type: "Web App"
// 5. Execute as: "Me", Who has access: "Anyone"
// 6. Klik Deploy, copy URL yang diberikan
// 7. Paste URL tersebut ke variabel WEBAPP_URL di file HTML
// =============================================================

const SPREADSHEET_ID = ""; // KOSONGKAN - Script otomatis buat spreadsheet baru saat pertama deploy

// Sheet names
const SHEET_USERS       = "Users";
const SHEET_BOOKS       = "Books";
const SHEET_SUBMISSIONS = "Submissions";
const SHEET_ORDERS      = "Orders";

// -------------------------------------------------------
// HANDLE GET REQUEST - Untuk mengambil data (READ)
// -------------------------------------------------------
function doGet(e) {
  try {
    const action = e.parameter.action;
    const ss = getOrCreateSpreadsheet();

    if (action === "getAll") {
      const data = {
        users:       getSheetData(ss, SHEET_USERS),
        books:       getSheetData(ss, SHEET_BOOKS),
        submissions: getSheetData(ss, SHEET_SUBMISSIONS),
        orders:      getSheetData(ss, SHEET_ORDERS)
      };
      return jsonResponse({ status: "ok", data });
    }

    if (action === "getBooks") {
      return jsonResponse({ status: "ok", data: getSheetData(ss, SHEET_BOOKS) });
    }

    if (action === "login") {
      const identifier = e.parameter.identifier || "";
      const password   = e.parameter.password   || "";
      const users      = getSheetData(ss, SHEET_USERS);
      const user       = users.find(u =>
        (u.email === identifier || u.phone === identifier) && u.password === password
      );
      if (user) {
        // Jangan kirim password ke client
        const safeUser = { id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role || "user" };
        return jsonResponse({ status: "ok", user: safeUser });
      } else {
        return jsonResponse({ status: "error", message: "Kredensial tidak valid" });
      }
    }

    if (action === "getSubmissions") {
      return jsonResponse({ status: "ok", data: getSheetData(ss, SHEET_SUBMISSIONS) });
    }

    if (action === "getOrders") {
      return jsonResponse({ status: "ok", data: getSheetData(ss, SHEET_ORDERS) });
    }

    return jsonResponse({ status: "error", message: "Action tidak dikenal" });

  } catch (err) {
    return jsonResponse({ status: "error", message: err.toString() });
  }
}

// -------------------------------------------------------
// HANDLE POST REQUEST - Untuk menyimpan data (WRITE)
// -------------------------------------------------------
function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const action  = payload.action;
    const ss      = getOrCreateSpreadsheet();

    // --- REGISTER USER BARU ---
    if (action === "registerUser") {
      const userData = payload.data;
      const users    = getSheetData(ss, SHEET_USERS);

      // Cek duplikasi email
      if (users.some(u => u.email === userData.email)) {
        return jsonResponse({ status: "error", message: "Email sudah terdaftar" });
      }

      userData.role      = "user";
      userData.createdAt = new Date().toISOString();
      appendSheetRow(ss, SHEET_USERS, userData);
      
      const safeUser = { id: userData.id, name: userData.name, email: userData.email, phone: userData.phone, role: "user" };
      return jsonResponse({ status: "ok", user: safeUser, message: "Registrasi berhasil" });
    }

    // --- TAMBAH BUKU BARU (Admin) ---
    if (action === "addBook") {
      const book      = payload.data;
      book.createdAt  = new Date().toISOString();
      appendSheetRow(ss, SHEET_BOOKS, book);
      return jsonResponse({ status: "ok", message: "Buku berhasil ditambahkan", book });
    }

    // --- HAPUS BUKU (Admin) ---
    if (action === "deleteBook") {
      const bookId = payload.bookId;
      deleteRowByKey(ss, SHEET_BOOKS, "id", bookId);
      return jsonResponse({ status: "ok", message: "Buku berhasil dihapus" });
    }

    // --- SUBMIT NASKAH ---
    if (action === "addSubmission") {
      const sub     = payload.data;
      sub.createdAt = new Date().toISOString();
      appendSheetRow(ss, SHEET_SUBMISSIONS, sub);
      return jsonResponse({ status: "ok", message: "Naskah berhasil dikirim" });
    }

    // --- BUAT PESANAN BARU ---
    if (action === "addOrder") {
      const order     = payload.data;
      order.createdAt = new Date().toISOString();
      appendSheetRow(ss, SHEET_ORDERS, order);
      return jsonResponse({ status: "ok", message: "Pesanan berhasil dibuat" });
    }

    return jsonResponse({ status: "error", message: "Action tidak dikenal" });

  } catch (err) {
    return jsonResponse({ status: "error", message: err.toString() });
  }
}

// -------------------------------------------------------
// HELPER: Ambil atau buat Spreadsheet
// -------------------------------------------------------
function getOrCreateSpreadsheet() {
  // Coba pakai spreadsheet aktif (jika script terikat ke file)
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    if (ss) {
      initSheets(ss);
      return ss;
    }
  } catch (e) { /* script tidak terikat ke file */ }

  // Coba cari berdasarkan ID tersimpan di PropertiesService
  const props = PropertiesService.getScriptProperties();
  let ssId    = props.getProperty("SPREADSHEET_ID");

  if (ssId) {
    try {
      const ss = SpreadsheetApp.openById(ssId);
      initSheets(ss);
      return ss;
    } catch(e) { /* file tidak ditemukan, buat baru */ }
  }

  // Buat spreadsheet baru
  const ss = SpreadsheetApp.create("Nara Pustaka - Database");
  props.setProperty("SPREADSHEET_ID", ss.getId());
  initSheets(ss);

  // Log URL spreadsheet ke console agar admin bisa menyimpannya
  Logger.log("Spreadsheet baru dibuat: " + ss.getUrl());
  return ss;
}

// -------------------------------------------------------
// HELPER: Inisialisasi sheet dengan header jika belum ada
// -------------------------------------------------------
function initSheets(ss) {
  const schemas = {
    [SHEET_USERS]:       ["id", "name", "email", "phone", "password", "role", "createdAt"],
    [SHEET_BOOKS]:       ["id", "title", "author", "category", "price", "cover", "status", "createdAt"],
    [SHEET_SUBMISSIONS]: ["id", "author", "category", "title", "synopsis", "fileUrl", "status", "date", "createdAt"],
    [SHEET_ORDERS]:      ["id", "customer", "email", "address", "items", "total", "status", "date", "createdAt"]
  };

  Object.entries(schemas).forEach(([name, headers]) => {
    let sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold").setBackground("#56B6C6").setFontColor("white");
      sheet.setFrozenRows(1);
    }
  });

  // Hapus sheet default "Sheet1" jika ada
  const defaultSheet = ss.getSheetByName("Sheet1");
  if (defaultSheet && ss.getSheets().length > 1) {
    ss.deleteSheet(defaultSheet);
  }
}

// -------------------------------------------------------
// HELPER: Baca semua data dari sheet sebagai array of objects
// -------------------------------------------------------
function getSheetData(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return []; // Hanya ada header atau kosong

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const rows    = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();

  return rows.map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i]; });
    return obj;
  }).filter(obj => obj.id !== "" && obj.id !== null && obj.id !== undefined);
}

// -------------------------------------------------------
// HELPER: Tambah baris baru ke sheet
// -------------------------------------------------------
function appendSheetRow(ss, sheetName, data) {
  const sheet   = ss.getSheetByName(sheetName);
  if (!sheet) return;
  
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const row     = headers.map(h => data[h] !== undefined ? data[h] : "");
  sheet.appendRow(row);
}

// -------------------------------------------------------
// HELPER: Hapus baris berdasarkan key-value
// -------------------------------------------------------
function deleteRowByKey(ss, sheetName, keyColumn, keyValue) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const headers     = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const colIndex    = headers.indexOf(keyColumn);
  if (colIndex === -1) return;

  const values = sheet.getRange(2, colIndex + 1, lastRow - 1, 1).getValues();
  for (let i = values.length - 1; i >= 0; i--) {
    if (String(values[i][0]) === String(keyValue)) {
      sheet.deleteRow(i + 2);
    }
  }
}

// -------------------------------------------------------
// HELPER: Format JSON response dengan CORS headers
// -------------------------------------------------------
function jsonResponse(data) {
  const output = ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  return output;
}

// -------------------------------------------------------
// FUNGSI TEST - Jalankan ini dari editor untuk verifikasi
// -------------------------------------------------------
function testSetup() {
  const ss = getOrCreateSpreadsheet();
  Logger.log("Spreadsheet URL: " + ss.getUrl());
  Logger.log("Sheets: " + ss.getSheets().map(s => s.getName()).join(", "));
  Logger.log("Setup berhasil!");
}
